# ans.hl7v2.fr.teleradiologie#0.1.0: Volet Téléradiologie

## Pages

* [Accueil](index.md)
* [Téléchargements](downloads.md)
* [Utilisation du champ OBX-4 – Observation Sub-ID](sub-id.md)
* [Table TLR_OBR_PROCEDURE](table_obr.md)
* [Artifacts Summary](artifacts.md)
* [Exemples de messages](exemples.md)
* [Diagramme de séquence - Spécification technique](diag_sequence.md)
* [Test](tests.md)
* [Volume 1 : Etude fonctionnelle](specifications_fonctionnelles.md)
* [Références documentaires](doc-ref.md)
* [Historique des versions](change-log.md)
* [Table TLR_OBSERVATION](table_obs.md)
* [Normes et Standards](norme_standard.md)
* [Table TLR_TYPE_ORGANISATION](table_orga.md)
* [Volume 2 : Détail des transactions](specifications_techniques.md)

## Resources

### ImplementationGuides

* [Volet Téléradiologie](index.md)
