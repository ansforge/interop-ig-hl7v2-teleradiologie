# Accueil - Volet Téléradiologie v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/hl7v2/teleradiologie/ImplementationGuide/ans.hl7v2.fr.teleradiologie | *Version*:0.1.0 |
| Draft as of 2026-01-07 | *Computable Name*:CISIS_TLR_HL7_V2 |

 **Brief description of this Implementation Guide**
 [Add a brief description of this IG in English] 

> Cet Implementation Guide n'est pas la version courante, il s'agit de la version en intégration continue soumise à des changements fréquents uniquement destinée à suivre les travaux en cours. La version courante sera accessible via l'URL canonique suite à la première release : http://interop.esante.gouv.fr/ig/fhir/[code - ig]

### Introduction

Définir ici de quoi parle l’IG (En termes non expert, compréhensible par un patient). Rajouter également les détails techniques sur le contexte et le besoin de cet IG

Les principales sections de l’IG sont :

* Le contexte de l’IG, quelle problématique il résout
* Ce que les Implémenteurs doivent mettre en place
* Un onglet “Ressources de conformité” pour s’assurer d’un schéma global entre tous les IGs

### Périmètre du projet

Définir en quelques lignes en anglais quel est le périmètre du projet

Toujours laisser l’onglet “Ressources de conformité” pour s’assurer d’une cohérence globales entre tous les IGs

### Auteurs et contributeurs

| | | | |
| :--- | :--- | :--- | :--- |
| **Primary Editor** | Prenom Nom | Agence du Numérique en Santé | prenom.nom@address.email |

### Dépendances



### Propriété intellectuelle

Pas dusage de PI externe (autre que celles de la spécification FHIR)

