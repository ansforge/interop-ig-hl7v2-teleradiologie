# Exemples de messages - Volet Téléradiologie v0.1.0

* [**Table of Contents**](toc.md)
* [**Annexes**](annexes.md)
* **Exemples de messages**

## Exemples de messages

### Nom du flux

Description du flux

### Construction du flux

Explication de comment doit être construit le flux

