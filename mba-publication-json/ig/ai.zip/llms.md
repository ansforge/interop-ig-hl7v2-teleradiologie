# ans.hl7v2.fr.teleradiologie#0.1.0-ballot: Volet Téléradiologie

## Pages

* [Accueil](index.md)
* [Volume 1 : Etude fonctionnelle](specifications_fonctionnelles.md)
* [Utilisation du champ OBX-4 – Observation Sub-ID](sub-id.md)
* [Historique des versions](change-log.md)
* [Diagramme de séquence - Spécification technique](diag_sequence.md)
* [Table TLR_OBSERVATION](table_obs.md)
* [Exemples de messages](exemples.md)
* [Table TLR_OBR_PROCEDURE](table_obr.md)
* [Table TLR_TYPE_ORGANISATION](table_orga.md)
* [Normes et Standards](norme_standard.md)
* [Artifacts Summary](artifacts.md)
* [Téléchargements](downloads.md)
* [Volume 2 : Détail des transactions](specifications_techniques.md)
* [Références documentaires](doc-ref.md)
* [Test](tests.md)

## Resources

### ImplementationGuides

* [Volet Téléradiologie](index.md)
